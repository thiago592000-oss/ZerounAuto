package com.zeroun.automed

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    class Resp(val code: Int, val json: JSONObject?)

    /** Lança IOException se não houver conexão. */
    fun call(c: Context, rota: String, body: JSONObject, auth: Boolean): Resp {
        val base = Store.apiBase(c).trimEnd('/')
        val conn = URL("$base/api/app/$rota").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (auth) {
                val id = Store.deviceId(c)
                val tk = Store.token(c)
                if (id != null && tk != null) {
                    conn.setRequestProperty("X-Device-Id", id)
                    conn.setRequestProperty("Authorization", "Bearer $tk")
                }
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(txt) } catch (e: Exception) { null }
            return Resp(code, json)
        } finally {
            conn.disconnect()
        }
    }
}